./compressedpkh
./b58converter2.sh `./compressedpkh`
