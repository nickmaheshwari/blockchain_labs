#if [ $# -ne 1 ]; then
#   echo "USAGE:  $0 PublicKeyCompressed66Bytes"
#   exit
#fi

#echo $3
lastparm="${!#}"

echo "Working with Compressed Public Key: $lastparm"

V0=`echo -n $lastparm | xxd -r -p | openssl dgst -sha256 | cut -c 10-`
echo "STAGE 2 is: $V0"

V1=`echo -n $lastparm | xxd -r -p | openssl dgst -sha256 -binary | openssl dgst -rmd160 | cut -c 10-`
echo "STAGE 3 is: $V1" # NOTE that we pass the binary output of SHA-256 from Stage 2 directly into Stage 3's RIPEMD-160

OOS='00'
V2="$OOS$V1"
echo "STAGE 4 is: $V2"

V3=`echo -n $V2 | xxd -r -p | openssl dgst -sha256 | cut -c 10-`
echo "STAGE 5 is: $V3"

s6=`echo -n $V3 | xxd -r -p | openssl dgst -sha256 | cut -c 10-`
echo "STAGE 6 is: $s6"

V4=`echo -n $V3 | xxd -r -p | openssl dgst -sha256 | cut -c 10-17`
echo "STAGE 7 is: $V4"

V5=$V2$V4
echo "STAGE 8 is: $V5"

V6=`echo -n $V5 | xxd -r -p | base58`
echo "STAGE 9 is: $V6"
echo ""
